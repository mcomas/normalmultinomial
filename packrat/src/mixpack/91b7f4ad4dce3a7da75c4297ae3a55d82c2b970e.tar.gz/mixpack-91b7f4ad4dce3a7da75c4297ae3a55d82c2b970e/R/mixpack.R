#' @useDynLib mixpack
#' @importFrom Rcpp sourceCpp
NULL