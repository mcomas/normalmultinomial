#' mixpack.
#'
#' @name mixpack
#' @docType package
NULL 
