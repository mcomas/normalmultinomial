# mixpack

The mixpack package is a pack of functions to deal with mixtures and to combine the components of a mixture using different approaches
## Installation

mixpack is under construction and therefore, it is not yet available from CRAN, but you can install it from github with:

```R
# install.packages("devtools")
devtools::install_github('mcomas/mixpack')
```
